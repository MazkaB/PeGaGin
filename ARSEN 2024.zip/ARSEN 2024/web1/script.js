// script.js

document.addEventListener('DOMContentLoaded', () => {
    /* -----------------------------------
       1. Loader Handling
    ----------------------------------- */
    const loader = document.getElementById('loader');
    window.addEventListener('load', () => {
        if (typeof gsap !== 'undefined') {
            gsap.to(loader, { duration: 0.5, opacity: 0, display: 'none', ease: "power1.out" });
        } else {
            // Fallback jika GSAP tidak terload
            loader.style.display = 'none';
        }
    });

    /* -----------------------------------
       2. Initialize AOS (Animate On Scroll)
    ----------------------------------- */
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 1000,
            once: true,
        });
    }

    /* -----------------------------------
       3. Navbar Scroll Effect
    ----------------------------------- */
    const nav = document.querySelector('nav');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }
    });

    /* -----------------------------------
       4. Hamburger Menu Toggle
    ----------------------------------- */
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');

    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        hamburger.classList.toggle('active');
    });

    // Close menu when link is clicked
    navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            if (navLinks.classList.contains('active')) {
                navLinks.classList.remove('active');
                hamburger.classList.remove('active');
            }
        });
    });

    /* -----------------------------------
       5. Dark Mode Toggle
    ----------------------------------- */
    const themeToggleBtn = document.getElementById('theme-toggle');
    const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");

    // Function to set map tile layer based on theme
    function setMapTheme(isDark) {
        // Remove existing tile layers
        hospitalMap.eachLayer(layer => {
            if (layer instanceof L.TileLayer) {
                hospitalMap.removeLayer(layer);
            }
        });

        // Add appropriate tile layer
        if (isDark) {
            L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="https://carto.com/">CARTO</a>'
            }).addTo(hospitalMap);
        } else {
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '© OpenStreetMap contributors'
            }).addTo(hospitalMap);
        }
    }

    /* -----------------------------------
       6. Initialize Leaflet map and Fix Icons
    ----------------------------------- */
    const mapElement = document.getElementById('map');
    const hospitalMap = L.map(mapElement).setView([0, 0], 13);

    // Disable specific interactions until user locates their position
    hospitalMap.dragging.disable();
    hospitalMap.touchZoom.disable();
    hospitalMap.doubleClickZoom.disable();
    hospitalMap.scrollWheelZoom.disable();
    hospitalMap.boxZoom.disable();
    hospitalMap.keyboard.disable();
    hospitalMap.zoomControl.remove();

    // Fix Leaflet's default icon paths
    delete L.Icon.Default.prototype._getIconUrl;

    L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png'
    });

    // Check local storage for theme preference
    const currentTheme = localStorage.getItem("theme");
    const isDarkMode = currentTheme === "dark" || (!currentTheme && prefersDarkScheme.matches);

    // Initialize Nearest Hospital Finder tile layer based on initial theme
    setMapTheme(isDarkMode);

    if (currentTheme === "dark") {
        document.body.classList.add("dark");
        themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
    } else if (currentTheme === "light") {
        document.body.classList.remove("dark");
        themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
    } else if (prefersDarkScheme.matches) {
        document.body.classList.add("dark");
        themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
    }

    themeToggleBtn.addEventListener("click", function() {
        document.body.classList.toggle("dark");
        let theme = "light";
        if (document.body.classList.contains("dark")) {
            themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            theme = "dark";
        } else {
            themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
        }
        localStorage.setItem("theme", theme);

        // Update map tile layer based on theme
        const darkModeEnabled = document.body.classList.contains("dark");
        setMapTheme(darkModeEnabled);
    });

    /* -----------------------------------
       7. Initialize particles.js
    ----------------------------------- */
    if (typeof particlesJS !== 'undefined') {
        particlesJS.load('particles-js', 'particles.json', function() {
            console.log('particles.js loaded - callback');
        });
    }

    /* -----------------------------------
       8. Prediction Form Submission
    ----------------------------------- */
    const form = document.getElementById('predictionForm');
    const resultDiv = document.getElementById('result');

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        // Mengambil nilai dari formulir
        const age = parseInt(document.getElementById('age').value);
        const hemoglobin = parseFloat(document.getElementById('hemoglobin').value);
        const bloodPressure = parseInt(document.getElementById('bloodPressure').value);
        const bloodGlucose = parseInt(document.getElementById('bloodGlucose').value);
        const hypertension = parseInt(document.getElementById('hypertension').value);
        const pedalEdema = parseInt(document.getElementById('pedalEdema').value);

        // Validasi data input
        if (isNaN(age) || isNaN(hemoglobin) || isNaN(bloodPressure) || isNaN(bloodGlucose) || isNaN(hypertension) || isNaN(pedalEdema)) {
            alert('Mohon isi semua field dengan benar.');
            return;
        }

        // Simulasi Prediksi (Ini harus diganti dengan panggilan ke backend ML Anda)
        let prediction = '';
        let predictionClass = '';

        // Logika sederhana untuk simulasi
        if (age > 50 || hemoglobin < 12 || bloodPressure > 130 || bloodGlucose > 140 || hypertension === 1 || pedalEdema === 1) {
            prediction = 'Anda berisiko tinggi menderita Penyakit Ginjal Kronis (CKD). Disarankan untuk segera berkonsultasi dengan dokter.';
            predictionClass = 'failure';
        } else {
            prediction = 'Anda memiliki risiko rendah menderita Penyakit Ginjal Kronis (CKD). Tetap jaga kesehatan ginjal Anda!';
            predictionClass = 'success';
        }

        // Menampilkan hasil prediksi dengan animasi
        resultDiv.innerHTML = `<h3>Hasil Prediksi:</h3><p>${prediction}</p>`;
        resultDiv.className = `result ${predictionClass}`;
        resultDiv.style.display = 'block';
        if (typeof gsap !== 'undefined') {
            gsap.fromTo(resultDiv, { opacity: 0, y: -20 }, { opacity: 1, y: 0, duration: 0.5 });
        } else {
            resultDiv.style.opacity = '1';
        }
    });

    /* -----------------------------------
       9. Kontak Form Submission
    ----------------------------------- */
    const contactForm = document.getElementById('contactForm');
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        // Implementasikan logika pengiriman form, misalnya menggunakan AJAX atau integrasi dengan backend
        alert('Terima kasih telah menghubungi kami! Pesan Anda telah diterima.');
        contactForm.reset();
    });

    /* -----------------------------------
       10. Animasi Parallax pada Background
    ----------------------------------- */
    window.addEventListener('scroll', () => {
        const homeSection = document.querySelector('.home-section');
        const scrollPosition = window.scrollY;
        homeSection.style.backgroundPositionY = `${scrollPosition * 0.5}px`;
    });

    /* -----------------------------------
       11. Nearest Hospital Finder Functionality
    ----------------------------------- */
    // Nearest Hospital Finder Elements
    const locateBtn = document.getElementById('locate-btn');
    const mapElement = document.getElementById('map');

    // Inisialisasi peta Leaflet
    const map = L.map(mapElement).setView([0, 0], 13);

    // Menambahkan tiles OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Memperbaiki path ikon default Leaflet
    delete L.Icon.Default.prototype._getIconUrl;

    L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png'
    });

    // Menambahkan marker dan popup untuk lokasi pengguna
    let userMarker;
    function displayUserLocation(lat, lon) {
        if (userMarker) {
            userMarker.setLatLng([lat, lon]);
        } else {
            userMarker = L.marker([lat, lon]).addTo(map)
                .bindPopup("Anda berada di sini.")
                .openPopup();
        }
        map.setView([lat, lon], 13);
    }

    // Mengambil dan menampilkan rumah sakit terdekat
    function findNearbyHospitals(lat, lon) {
        const radius = 5000; // Radius 5 km
        const query = `[out:json];
            node["amenity"="hospital"](around:${radius},${lat},${lon});
            out;`;

        loadingDiv.style.display = 'flex'; // Show loading

        console.log("Fetching hospitals with query:", query);

        fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                // Menyembunyikan indikator loading
                // loadingDiv.style.display = 'none';

                if (data.elements.length > 0) {
                    data.elements.forEach(hospital => {
                        const { lat, lon, tags } = hospital;
                        L.marker([lat, lon]).addTo(map)
                            .bindPopup(tags.name || "Rumah Sakit Tanpa Nama");
                    });
                } else {
                    alert("Tidak ditemukan rumah sakit terdekat.");
                }
            })
            .catch(error => {
                // Menyembunyikan indikator loading
                // loadingDiv.style.display = 'none';
                console.error("Error fetching hospital data:", error);
                alert("Terjadi kesalahan saat mencari rumah sakit terdekat.");
            });
    }

    // Geolokasi dan memicu pencarian rumah sakit
    locateBtn.addEventListener('click', () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    displayUserLocation(lat, lon);
                    findNearbyHospitals(lat, lon);
                },
                (error) => {
                    console.error("Geolocation error:", error);
                    alert("Tidak dapat mengambil lokasi Anda. Pastikan Anda telah memberikan izin akses lokasi.");
                }
            );
        } else {
            alert("Geolokasi tidak didukung oleh browser ini.");
        }
    });

    // Invalidate size after a short delay to ensure container is rendered
    setTimeout(() => {
        hospitalMap.invalidateSize();
    }, 500);
});
