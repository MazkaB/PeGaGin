document.addEventListener('DOMContentLoaded', () => {
    const locateBtn = document.getElementById('locate-btn');
    const mapElement = document.getElementById('map');

    // Initialize Leaflet map
    const map = L.map(mapElement).setView([0, 0], 13);

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Add marker and popup for user's location
    let userMarker;
    function displayUserLocation(lat, lon) {
        if (userMarker) {
            userMarker.setLatLng([lat, lon]);
        } else {
            userMarker = L.marker([lat, lon]).addTo(map)
                .bindPopup("You are here.")
                .openPopup();
        }
        map.setView([lat, lon], 13);
    }

    // Fetch and display nearby hospitals
    function findNearbyHospitals(lat, lon) {
        const radius = 10000; // 5 km radius
        const query = `[out:json];
            node["amenity"="hospital"](around:${radius},${lat},${lon});
            out;`;

        fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                if (data.elements.length > 0) {
                    data.elements.forEach(hospital => {
                        const { lat, lon, tags } = hospital;
                        L.marker([lat, lon]).addTo(map)
                            .bindPopup(tags.name || "Unnamed Hospital");
                    });
                } else {
                    alert("No hospitals found nearby.");
                }
            })
            .catch(error => console.error("Error fetching hospital data:", error));
    }

    // Geolocation and trigger hospital search
    locateBtn.addEventListener('click', () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    displayUserLocation(lat, lon);
                    findNearbyHospitals(lat, lon);
                },
                (error) => {
                    console.error("Geolocation error:", error);
                    alert("Unable to retrieve your location.");
                }
            );
        } else {
            alert("Geolocation is not supported by this browser.");
        }
    });
});
