// script.js

document.addEventListener("DOMContentLoaded", () => {
/* -----------------------------------
   1. Penanganan Formulir Prediksi
----------------------------------- */
const predictionForm = document.getElementById("predictionForm");
const resultDiv = document.getElementById("result");
const loadingDiv = document.getElementById("loading");

// Inisialisasi variabel untuk model ONNX
let session;

async function loadModel() {
    // Menampilkan loading spinner saat model dimuat
    loadingDiv.style.display = "block";
    try {
        // Memuat model ONNX
        session = await ort.InferenceSession.create('./assets/models/AdaBoost_model.onnx');
        console.log("Model ONNX berhasil dimuat.");
    } catch (error) {
        console.error("Gagal memuat model ONNX:", error);
        resultDiv.innerHTML = "<p>Terjadi kesalahan saat memuat model prediksi. Silakan coba lagi nanti.</p>";
    } finally {
        loadingDiv.style.display = "none";
    }
}

// Panggil fungsi untuk memuat model saat halaman dimuat
loadModel();

predictionForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    // Validasi input
    if (!predictionForm.checkValidity()) {
        predictionForm.reportValidity();
        return;
    }

    // Menampilkan loading spinner
    loadingDiv.style.display = "block";
    resultDiv.innerHTML = "";

    // Mengambil nilai input dari formulir
    const age = parseFloat(document.getElementById("age").value);
    const hemoglobin = parseFloat(document.getElementById("hemoglobin").value);
    const bloodPressure = parseFloat(document.getElementById("bloodPressure").value);
    const bloodGlucose = parseFloat(document.getElementById("bloodGlucose").value);
    const hypertension = parseFloat(document.getElementById("hypertension").value);
    const pedalEdema = parseFloat(document.getElementById("pedalEdema").value);

    // Membuat tensor input
    const inputTensor = new ort.Tensor('float32', [age, hemoglobin, bloodPressure, bloodGlucose, hypertension, pedalEdema], [1, 6]);

    try {
        // Menjalankan inferensi
        const feeds = { 'float_input': inputTensor };
        const results = await session.run(feeds);

        // Mendapatkan hasil prediksi
        const output = results['label'];
        const prediction = output.data[0]; // Asumsikan output adalah array dengan satu nilai

        // Menyembunyikan loading spinner
        loadingDiv.style.display = "none";

        // Menampilkan hasil prediksi
        if (prediction === 1) {
            resultDiv.innerHTML = "<p><strong>Hasil:</strong> Anda berisiko terkena Penyakit Ginjal Kronis (CKD). Disarankan untuk konsultasi dengan dokter.</p>";
        } else {
            resultDiv.innerHTML = "<p><strong>Hasil:</strong> Anda tidak berisiko terkena Penyakit Ginjal Kronis (CKD) berdasarkan data yang diberikan.</p>";
        }
    } catch (error) {
        console.error("Error saat melakukan prediksi:", error);
        loadingDiv.style.display = "none";
        resultDiv.innerHTML = "<p>Terjadi kesalahan saat memproses data. Silakan coba lagi nanti.</p>";
    }
});


    /* -----------------------------------
       2. Fitur Peta Rumah Sakit Terdekat
    ----------------------------------- */
    const locateBtn = document.getElementById('locate-btn');
    const mapElement = document.getElementById('map');

    // Inisialisasi peta Leaflet
    const map = L.map(mapElement).setView([0, 0], 13);

    // Menambahkan tiles OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Memperbaiki path ikon default Leaflet
    delete L.Icon.Default.prototype._getIconUrl;

    L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png'
    });

    // Menambahkan marker dan popup untuk lokasi pengguna
    let userMarker;
    function displayUserLocation(lat, lon) {
        if (userMarker) {
            userMarker.setLatLng([lat, lon]);
        } else {
            userMarker = L.marker([lat, lon]).addTo(map)
                .bindPopup("Anda berada di sini.")
                .openPopup();
        }
        map.setView([lat, lon], 13);
    }

    // Mengambil dan menampilkan rumah sakit terdekat
    function findNearbyHospitals(lat, lon) {
        const radius = 10000; // Radius 10 km
        const query = `[out:json];
            node["amenity"="hospital"](around:${radius},${lat},${lon});
            out;`;

        fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                if (data.elements.length > 0) {
                    data.elements.forEach(hospital => {
                        const { lat, lon, tags } = hospital;
                        L.marker([lat, lon]).addTo(map)
                            .bindPopup(tags.name || "Rumah Sakit Tanpa Nama");
                    });
                } else {
                    alert("Tidak ditemukan rumah sakit terdekat.");
                }
            })
            .catch(error => {
                console.error("Error fetching hospital data:", error);
                alert("Terjadi kesalahan saat mengambil data rumah sakit.");
            });
    }

    // Geolokasi dan memicu pencarian rumah sakit
    locateBtn.addEventListener('click', () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    displayUserLocation(lat, lon);
                    findNearbyHospitals(lat, lon);
                },
                (error) => {
                    console.error("Geolocation error:", error);
                    alert("Tidak dapat mengambil lokasi Anda. Pastikan Anda telah memberikan izin akses lokasi.");
                }
            );
        } else {
            alert("Geolokasi tidak didukung oleh browser ini.");
        }
    });

    /* -----------------------------------
       3. Responsive Navbar
    ----------------------------------- */
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    hamburger.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        hamburger.classList.toggle('toggle');
    });

    navMenu.querySelectorAll('a').forEach(n => n.addEventListener('click', () => {
        navMenu.classList.remove('active');
        hamburger.classList.remove('toggle');
    }));

    /* -----------------------------------
       4. Back to Top Button
    ----------------------------------- */
    const backToTopBtn = document.querySelector('.back-to-top');

    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            backToTopBtn.style.display = "block";
        } else {
            backToTopBtn.style.display = "none";
        }
    });

    /* -----------------------------------
       5. Dark Mode Toggle
    ----------------------------------- */
    const darkModeToggle = document.querySelector('.dark-mode-toggle');
    const body = document.body;

    darkModeToggle.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        // Simpan preferensi pengguna di localStorage
        if (body.classList.contains('dark-mode')) {
            localStorage.setItem('darkMode', 'enabled');
        } else {
            localStorage.setItem('darkMode', 'disabled');
        }
    });

    // Periksa preferensi pengguna saat halaman dimuat
    if (localStorage.getItem('darkMode') === 'enabled') {
        body.classList.add('dark-mode');
    }

    /* -----------------------------------
       6. Newsletter Subscription Form
    ----------------------------------- */
    const newsletterForm = document.getElementById('newsletterForm');

    newsletterForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const email = document.getElementById('newsletterEmail').value;

        // Validasi email sederhana
        if (!email) {
            alert('Silakan masukkan email yang valid.');
            return;
        }

        // Lakukan tindakan untuk menyimpan email (Anda perlu membuat API untuk ini)
        alert(`Terima kasih telah berlangganan, ${email}!`);
        newsletterForm.reset();
    });

    /* -----------------------------------
       7. Contact Form
    ----------------------------------- */
    const contactForm = document.getElementById('contactForm');

    contactForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = document.getElementById('name').value;

        // Validasi input
        if (!contactForm.checkValidity()) {
            contactForm.reportValidity();
            return;
        }

        // Lakukan tindakan untuk mengirim pesan (Anda perlu membuat API untuk ini)
        alert(`Terima kasih, ${name}! Pesan Anda telah terkirim.`);
        contactForm.reset();
    });

    /* -----------------------------------
       8. Animate On Scroll Initialization
    ----------------------------------- */
    AOS.init({
        duration: 1000,
        once: true,
    });

    /* -----------------------------------
       9. Multilingual Support (Mock)
    ----------------------------------- */
    const langIdBtn = document.getElementById('lang-id');
    const langEnBtn = document.getElementById('lang-en');

    langIdBtn.addEventListener('click', () => {
        // Fungsi untuk mengganti teks ke Bahasa Indonesia
        langIdBtn.classList.add('active');
        langEnBtn.classList.remove('active');
        // Implementasi pergantian bahasa di sini
        alert('Bahasa Indonesia dipilih (Fitur belum diimplementasikan).');
    });

    langEnBtn.addEventListener('click', () => {
        // Fungsi untuk mengganti teks ke Bahasa Inggris
        langEnBtn.classList.add('active');
        langIdBtn.classList.remove('active');
        // Implementasi pergantian bahasa di sini
        alert('English language selected (Feature not implemented yet).');
    });
});
